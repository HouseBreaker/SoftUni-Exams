﻿namespace Vegetable_Ninja.IO
{
	public interface IReader
	{
		string ReadLine();
	}
}
