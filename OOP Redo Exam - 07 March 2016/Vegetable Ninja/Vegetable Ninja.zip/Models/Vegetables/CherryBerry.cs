﻿namespace Vegetable_Ninja.Models.Vegetables
{
	public class CherryBerry : Vegetable
	{
		public CherryBerry()
			: base(0, 10, 3, 'B')
		{
		}
	}
}
