﻿namespace Vegetable_Ninja.Models.Vegetables
{
	public class Asparagus : Vegetable 
	{
		public Asparagus()
			: base(5, -5, 2, 'A')
		{
		}
	}
}
