namespace Vegetable_Ninja.Models.Vegetables
{
	public class Broccoli : Vegetable
	{
		public Broccoli()
			: base(10, 0, 3, 'C')
		{
		}
	}
}