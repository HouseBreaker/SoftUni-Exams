﻿namespace Vegetable_Ninja.Models.Vegetables
{
	public class BlankSpace : Vegetable
	{
		public BlankSpace()
			: base(0, 0, int.MaxValue, '-')
		{
		}
	}
}
