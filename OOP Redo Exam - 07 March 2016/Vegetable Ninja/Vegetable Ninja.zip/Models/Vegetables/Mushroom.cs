﻿namespace Vegetable_Ninja.Models.Vegetables
{
	public class Mushroom : Vegetable
	{
		public Mushroom()
			: base(-10, -10, 5, 'M')
		{
		}
	}
}
