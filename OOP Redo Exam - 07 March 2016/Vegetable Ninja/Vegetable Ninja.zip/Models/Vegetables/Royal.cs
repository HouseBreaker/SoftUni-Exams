﻿namespace Vegetable_Ninja.Models.Vegetables
{
	public class Royal : Vegetable
	{
		public Royal()
			: base(20, 10, 10, 'R')
		{
		}
	}
}
